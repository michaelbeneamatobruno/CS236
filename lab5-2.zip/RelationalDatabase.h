#pragma once

using namespace std;

class RelationalDatabase {
    protected:
    public:
    
    
    
}